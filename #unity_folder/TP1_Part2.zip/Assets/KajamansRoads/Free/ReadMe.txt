There are two roads included

6 lane highway
- 20 km long
- 28 meters wide (tarmac only)
- 10710 verts
- 10696 tris

2 lane road
- 10 km long
- 12 meters wide
- 13340 verts
- 13330 tris

Roads are optimized for best ratio between smoothness and polygon numbers.
Prefabs for computer and mobile use.

Check the Kajaman's Roads Megapack version for another 80+ roads of various types.